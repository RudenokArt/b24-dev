<?php require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php"); ?>


<?php $APPLICATION->IncludeComponent(
  "klimsol:tickets_faq",
  "",
  Array()
); ?>


<?php require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php"); ?>






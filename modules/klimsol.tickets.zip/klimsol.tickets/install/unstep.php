<?if(!check_bitrix_sessid()) return;?>
<?
echo CAdminMessage::ShowNote("The module was successfully removed from the system");
?>
<?php require($_SERVER["DOCUMENT_ROOT"]."/bitrix/header.php"); ?>


<?php $APPLICATION->IncludeComponent(
  "klimsol:deal_fields_manager",
  "",
  Array()
); ?>


<?php require($_SERVER["DOCUMENT_ROOT"]."/bitrix/footer.php"); ?>






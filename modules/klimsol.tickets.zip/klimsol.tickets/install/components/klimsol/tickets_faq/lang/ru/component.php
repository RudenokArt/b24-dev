<?php 
$MESS['date'] = 'Дата';
$MESS['add_question'] = 'Добавить вопрос';
$MESS['question'] = 'Вопрос';
$MESS['answer'] = 'Ответ';
$MESS['save'] = 'Сохранить';
$MESS['cancel'] = 'Отменить';
$MESS['required'] = 'Заполните обязательные поля';
$MESS['delete'] = 'Удалить';
$MESS['update'] = 'Изменить';
$MESS['faq'] = 'Часто зазаваемые вопросы';
$MESS['update_question'] = 'Изменить вопрос';
?>
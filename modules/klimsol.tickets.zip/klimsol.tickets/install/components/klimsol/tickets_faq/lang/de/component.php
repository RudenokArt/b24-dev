<?php 
$MESS['date'] = 'Datum';
$MESS['add_question'] = 'Eine Frage hinzufügen';
$MESS['question'] = 'Frage';
$MESS['answer'] = 'Antwort';
$MESS['save'] = 'speichern';
$MESS['cancel'] = 'stornieren';
$MESS['required'] = 'Füllen Sie die erforderlichen Felder aus';
$MESS['delete'] = 'Löschen';
$MESS['update'] = 'Update';
$MESS['faq'] = 'FAQ`S';
$MESS['update_question'] = 'Eine Frage aktualisieren';



?>


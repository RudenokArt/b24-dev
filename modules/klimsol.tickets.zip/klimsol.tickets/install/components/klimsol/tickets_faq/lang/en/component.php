<?php 
$MESS['date'] = 'Date';
$MESS['add_question'] = 'Add a question';
$MESS['question'] = 'Question';
$MESS['answer'] = 'Answer';
$MESS['save'] = 'save';
$MESS['cancel'] = 'cancel';
$MESS['required'] = 'Fill in the required fields';
$MESS['delete'] = 'Delete';
$MESS['update'] = 'Update';
$MESS['faq'] = 'FAQ';
$MESS['update_question'] = 'Update a question';

?>
<?php 
$MESS['deal-fields-manager'] = 'Deal fields manager';


?>
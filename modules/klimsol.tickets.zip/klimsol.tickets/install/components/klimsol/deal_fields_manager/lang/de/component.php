<?php 
$MESS['deal-fields-manager'] = 'Deal Felder Manager';




?>


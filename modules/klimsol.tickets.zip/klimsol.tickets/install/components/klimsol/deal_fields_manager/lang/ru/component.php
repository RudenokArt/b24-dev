<?php 
$MESS['deal-fields-manager'] = 'Управление полями сделок';

?>
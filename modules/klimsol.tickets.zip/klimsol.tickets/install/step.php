<?if(!check_bitrix_sessid()) return;?>
<?
echo CAdminMessage::ShowNote("The module has been installed successfully");
?>